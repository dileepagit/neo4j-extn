var speakKeyStr;

function onExtensionMessage(request) {
  if (request['key'] != undefined) {
    speakKeyStr = request['key'];
  }
}

function getNodeId(){
  var nodeDetails = document.querySelector('[data-testid=vizInspector] li:nth-child(2) .value');
  if(nodeDetails){
    return nodeDetails.innerText;
  }
}

function keyDownSendNodeId(nodeId){
  chrome.tabs.query({
      active: true,
      currentWindow: true
    }, tabs => {
      chrome.tabs.sendMessage(
          tabs[0].id,
          {from: 'content', subject: 'addNode', nodeId: nodeId},
          function addNode(response){
          });
    });
}

function initContentScript() {
  chrome.extension.onRequest.addListener(onExtensionMessage);
  chrome.extension.sendRequest({'init': true}, onExtensionMessage);

  document.addEventListener('keydown', function(evt) {
    if (!document.hasFocus()) {
      return true;
    }
    var keyStr = keyEventToString(evt);
    if (keyStr == speakKeyStr && speakKeyStr.length > 0) {
      chrome.extension.sendRequest({'getNode': true}, keyDownSendNodeId);
      evt.stopPropagation();
      evt.preventDefault();
      return false;
    }
    return true;
  }, false);
  
  chrome.runtime.onMessage.addListener((msg, sender, callback) => {
    if ((msg.from === 'popup') && (msg.subject === 'getNode')) {
      var nodeId = getNodeId();
      callback(nodeId);
    }
  });
  
}

initContentScript();



