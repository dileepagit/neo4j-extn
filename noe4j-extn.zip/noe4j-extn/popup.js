var thisBg = null;
var nodeId = null;
var host = null;

document.addEventListener('DOMContentLoaded', function () {
    chrome.runtime.getBackgroundPage(function (bg) {
        thisBg = bg;
    });
    
    chrome.runtime.onMessage.addListener((msg, sender, callback) => {
      if ((msg.from === 'content') && (msg.subject === 'addNode')) {
        var nodeId = msg.nodeId;
        getNode(nodeId);
        callback(nodeId);
      }
    });
        
    chrome.tabs.query({
      active: true,
      currentWindow: true
    }, tabs => {
      host = tabs[0].url.match(/^(http|https):\/\/([^:/]+)/i)[2];
      chrome.tabs.sendMessage(
          tabs[0].id,
          {from: 'popup', subject: 'getNode'},
          function addNode(response){
            nodeId = response;
            
            getNode(nodeId);
          });
    });
});


function getNode(nodeId){
  if(nodeId){
    
  
    neo4j = neo4j.v1
    var driver = neo4j.driver("bolt://"+host+':'+localStorage['port'], neo4j.auth.basic(localStorage['username'], localStorage['password']));
    var session = driver.session();
    // Run a Cypher statement, reading the result in a streaming manner as records arrive:
    session
    .run('MATCH (s) WHERE ID(s) = '+nodeId+' RETURN s')
    .then(function (result) {
         result.records.forEach(function (record) {
              console.log(record);
              var nodes = null;
              if(!localStorage['nodes']){
                nodes = {};
              }else{
                nodes = JSON.parse(localStorage['nodes']);
              }
              nodes['id:'+nodeId] = record.get(0);
              localStorage['nodes'] = JSON.stringify(nodes);
              generateList(nodes);
         });
         session.close();
         driver.close();
    })
    .catch(function (error) {
         console.log(error);
         driver.close();
    });
    
    
  }
  generateList(JSON.parse(localStorage['nodes']));
}

function generateList(list) {
  if(list){
    var section = document.querySelector('body>section');
    var ol = document.createElement('ol');
    var li, p, em, code, text;
    var i = 0;
    Object.keys(list).forEach(function(key) {
      li = document.createElement('li');
      p = document.createElement('p');
      em = document.createElement('em');
      em.textContent = key;
      code = document.createElement('p');
      code.innerText = JSON.stringify(list[key]);
      // text = document.createTextNode(JSON.stringify(list[key]));
      p.appendChild(em);
      p.appendChild(code);
      // p.appendChild(text);
      li.appendChild(p);
      ol.appendChild(li);
      i++;
    });
    section.innerHTML = '';
    section.appendChild(ol);
  }
}
